<?php
    include('saklar.php');
?>
<!DOCTYPE html>
<head>
	<title>CLASH FOR MAGISK</title>
</head>
<body>
	<style type="text/css">
*{
	padding: 0;
	margin: 0;
	box-sizing: border-box;
	font-family: sans-serif;
}

body {
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100vh;
	background: url('../bg.png');
	background-size: cover;
}
.form-holder {
	width: 100%;
	max-width: 720px;
	padding: 10px;
	background: rgba(220,220,220, .0);
	border-radius: 15px;
	box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1), 0 2px 2px 0 rgba(0, 0, 0, 0.1);
}

.form-holder input {
	display: block;
	width: 100%;
	background: rgba(240,240,240, .5);
	border: none;
	font-size: 20px;
	padding: 15px;
	outline: none;
	border-radius: 40px;
	color: #555;
	margin: 20px auto;
	box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1), 0 2px 2px 0 rgba(0, 0, 0, 0.1);
}

.form-holder button {
	display: block;
	width: 100%;
	background: #2E2E3A;
	border: none;
	font-size: 20px;
	padding: 15px;
	outline: none;
	border-radius: 40px;
	color: #fff;
	margin: 20px auto;
	box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1), 0 2px 2px 0 rgba(0, 0, 0, 0.1);
}

.form-holder button:hover {
	opacity: .8;
}

.form-holder img {
	width: 100px;
	display: block;
	margin: 10px auto;
	opacity: .7;
}
	</style>
	<div class="form-holder">	
	<br>

 <a class="navbar-brand" href="index.php"><img src="adb/clash/yacd-gh-pages/yacd-128.png"></a> 
                                    <div class="col">
                                    <form method="post" action="saklar.php" id="create_form">
                                    <button type="submit" class="btn-primary" value="Create File" name="delete_file"> START</button>
                                    <form method="post" action="saklar.php" id="delete_form">
                                   	<button type="button" class="btn-primary" onclick="window.open('file.php')">FILE</button>
                                    <button type="submit" class="btn-danger" value="Delete File" name="create_file"> STOP</button>
                                   	<button type="button" class="btn-primary" onclick="window.open('https://t.me/trick_ngirit/')">JOIN TELEGRAM</button>
                                  	<button type="button" class="btn-primary" onclick="window.open('http://0.0.0.0:9090/ui')">DASBOARD</button></form>
<button onclick="fungsiSaya()">SEMBUNYIKAN LOG</button>
<div id="target">
           <?php
$file = fopen("$clashlogs","r");

while(! feof($file))
  {
  echo fgets($file). "<br />";
  }

fclose($file);
?>                     
</div>
<script>
function fungsiSaya() {
  var x = document.getElementById("target");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>                                                           	
</script>
</body>
</html>
