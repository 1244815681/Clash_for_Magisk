<?php
$clashlogs = "run/run.logs";
$pid = "run/clash.pid";
$moduledir = "modules/ClashforMagisk";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$action = $_REQUEST['actionButton'];
	switch ($action) {
		case "disable":
			$myfile = fopen("$moduledir/disable", "w") or die("Unable to open file!");
			break;
		case "enable":
			unlink("$moduledir/disable");
			header("Refresh:2");
			break;
	}
}
?>
<!DOCTYPE html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv='refresh' content='5'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard CFM</title>
    <link rel="icon" href="yacd-gh-pages/yacd-64.png" sizes="64x64">
    <style type="text/css">
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            font-family: mono;
        }

        body {
            justify-content: center;
            align-items: center;
            height: 100%;
            //background: url('bg.png');
            background-size: cover;
            background: #fff;
        }

        .form-holder {
            width: 87%;
            max-width: 400px;
            padding: 20px;
            margin: auto;
            background: rgba(220, 220, 220, .5);
            border-radius: 15px;
            box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1), 0 2px 2px 0 rgba(0, 0, 0, 0.1);
        }

        .form-holder button{
            display: block;
            width: 100%;
            background: #2E2E3A;
            border: none;
            font-size: 16px;
            padding: 15px;
            outline: none;
            border-radius: 40px;
            color: #fff;
            margin: 20px auto;
        }

        .form-holder button:hover {
            opacity: .8;
        }

        .form-holder img {
            width: 100px;
            display: block;
            margin: 10px auto;
        }

        #target{
            justify-content: center;
            align-items: center;
            padding: 20px;
            margin-top: 20px;
            margin: auto;
            width: 85%;
            height: 400px;
            max-width: 400px;
            max-height: 450px;
            background: rgba(220, 220, 220, .5);
            border-radius: 15px;
            box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1), 0 2px 2px 0 rgba(0, 0, 0, 0.1);
        }
        textarea {
          background: transparent;
          resize: none;
          border: 0 none;
          padding: 20px;
          margin: auto;
          width: 100%;
          height: 100%;
        }
        textarea:focus{
            outline: none;
        }
    </style>
</head>

<body>

    <div class="col">
        <div class="form-holder">
            <a href="/"><img src="yacd-gh-pages/yacd-128.png"></a>
            <div class="col">
                <form method="POST" action="">
                    <?php if (file_exists($pid)) { ?>
                    <button type="submit" value="disable" name="actionButton" onclick="showToast()"> Stop CFM</button>
                    <?php
					} else { ?>
                    <button type="submit" value="enable" name="actionButton" onclick="showToast()"> Start CFM</button>
                    <?php } ?>
                </form>
                <button class="button" onclick="window.open('http://0.0.0.0:9090/ui')">YACD</button>
                <button class="button" onclick="window.open('file.php')">File Editor</button>
                <button class="button" onclick="window.open('https://t.me/trick_ngirit')">Telegram</button>
                <button onclick="showLog()">Hide Log</button>

            </div>
        </div>
        <br>
        <div id="target">
                <?php
				$file = fopen("$clashlogs", "r");
				echo "<textarea nowrap readonly>";
				while (!feof($file)) {
					echo fgets($file);
				}
				echo "</textarea>";
				fclose($file);
				?>
        </div>
    </div>

    <script>
        function showLog() {
            var x = document.getElementById("target");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
    </script>
</body>

</html>