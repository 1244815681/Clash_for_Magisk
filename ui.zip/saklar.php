<?php
    $moduledir = "adb/modules/ClashforMagisk";    
    $clashlogs = "adb/clash/run/run.logs"; 
    $anudir = "files";          
if(isset($_POST['create_file']))
{
$myfile = fopen("$moduledir/disable", "w") or die("Unable to open file!");
$txt = "disable sukses\n";
fwrite($myfile, $txt);
fclose($myfile);
 }
if(isset($_POST['delete_file']))
{
 unlink("$moduledir/disable");
}
?>