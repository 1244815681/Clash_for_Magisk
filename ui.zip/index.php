<?php
$clashlogs = "adb/clash/run/run.logs";
$pid = "adb/clash/run/clash.pid";
$moduledir = "adb/modules/ClashforMagisk";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$action = $_REQUEST['actionButton'];
	switch ($action) {
		case "disable":
			$myfile = fopen("$moduledir/disable", "w") or die("Unable to open file!");
			break;
		case "enable":
			unlink("$moduledir/disable");
			header("Refresh:2");
			break;
	}
}
?>
<!DOCTYPE html>

<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Dashboard CFM</title>
	<link rel="icon" href="adb/clash/yacd-gh-pages/yacd-64.png" sizes="64x64">
</head>

<body>
	<style type="text/css">
		* {
			padding: 0;
			margin: 0;
			box-sizing: border-box;
			font-family: monospace;
			color: #000;
		}

		body {
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100%;
			background: #fff;
			background: url('../bg.png');
			background-size: cover;
		}

		.form-holder {
			width: 100%;
			max-width: 450px;
			padding: 10px;
			background: rgba(220,220,220,0);
			border-radius: 15px;
			box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0), 0 2px 2px 0 rgba(0, 0, 0, 0);
		}

		.form-holder input {
			display: light;
			width: 100%;
			background: rgba(240,240,240, .5);
			border: none;
			font-size: 20px;
			padding: 15px;
			outline: none;
			border-radius: 40px;
			color: #555;
			margin: 20px auto;
			box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1), 0 2px 2px 0 rgba(0, 0, 0, 0.1);
		}

		.form-holder button {
			display: block;
			width: 100%;
			background: #2E2E3A;
			border: none;
			font-size: 20px;
			padding: 15px;
			outline: none;
			border-radius: 15px;
			color: #bbd3a0;
			margin: 20px auto;
			box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1), 0 2px 2px 0 rgba(0, 0, 0, 0.1);
		}

		.form-holder button:hover {
			opacity: .8;
		}

		.form-holder img {
			width: 100px;
			display: block;
			margin: 10px auto;
			opacity: .7;
		}
	</style>
	<div class="form-holder">
		<br>
		<a class="navbar-brand" href="index.php"><img src="adb/clash/yacd/yacd-128.png"></a>
		<div class="col">
			<form method="POST" action="">
				<?php if (file_exists($pid)) { ?>
					<button type="submit" value="disable" name="actionButton" onclick="showToast()"> Stop CFM</button>
				<?php echo("<meta http-equiv='refresh' content='5'>"); } else { ?>
					<button type="submit" value="enable" name="actionButton" onclick="showToast()"> Start CFM</button>
				<?php } ?>
			</form>
			<button type="button" class="btn-primary" onclick="window.open('http://127.0.0.1:9090/ui/#/proxies')">Dashboard</button>
			<button type="button" class="btn-primary" onclick="window.open('http://sub.bonds.id')">Subconvert</button>
			<button type="button" class="btn-primary" onclick="window.open('https://t.me/trick_ngirit)">join Telegram</button>
			<button type="button" class="btn-primary" onclick="window.open('file.php')">File Editor</button>
			<button onclick="fungsiSaya()">Hide Log</button>
			<div id="target">
				<?php
				$file = fopen("$clashlogs", "r");

				while (!feof($file)) {
					echo fgets($file) . "<br />";
				}

				fclose($file);
				?>
			</div>
			<script>
				function fungsiSaya() {
					var x = document.getElementById("target");
					if (x.style.display === "none") {
						x.style.display = "block";
					} else {
						x.style.display = "none";
					}
				}

				function showToast() {
					var x = document.getElementById("snackbar");
					x.className = "show";
					setTimeout(function() {
						x.className = x.className.replace("show", "");
					}, 5000);
				}
			</script>
		</div>
	</div>
</body>

</html>